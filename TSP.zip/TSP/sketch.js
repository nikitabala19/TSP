var cities = [];
var distanceMatrix = [];
function setup() {
    
    h1 = createElement("h1","Visualization of TSP with Dynamic programming");
    h1.style('text-align:center');
    
    var p1 = createP("Please enter the number of seeds in below provided box. This seeds are generated randomly.");
    
    createP("");
    
    input1 = createInput();
    
    buttonGo = createButton("Plot Random Cities");
    
    createP("");
    
    createCanvas(600,400);

    createP("");
    
    buttonStart = createButton("Start");
    createP("");
    buttonNext = createButton("Next");

    buttonGo.mousePressed(buttonPlotRandomSeeds);
    buttonStart.mousePressed(buttonStartTSP);

}

function draw() {
  
    background(50);
    
    for(var i=0; i<cities.length; i++){
        cities[i].displayCity();
    }
    
    noLoop();
}

function buttonStartTSP() {
    
    var startCity = cities[0];
    var setOfCities = [];
    
    for(var i=1 ; i<cities.length; i++){
        setOfCities[i-1] = cities[i];
    }
//    console.log(startCity);
//    console.log(setOfCities);
    
    TSP(startCity, setOfCities, cities);
    loop();
}

function buttonPlotRandomSeeds() {
    seeds = input1.value();
    cities = [];
    distanceMatrix = [];
    
    for(var i=0; i<seeds; i++){
        cities[i] = new city(floor(random(0,width-20)),floor(random(0,height-20)));
    }
    
    for(var i=0; i<cities.length;i++){
        distanceMatrix[i] = [];
        for(var j=0;j<cities.length;j++){
            if(i!=j){
//                console.log("City " + i + ":" + cities[i].xCoordinate + ","+ cities[i].yCoordinate + "   City " + j + ":" +
//                cities[j].xCoordinate + ","+ cities[j].yCoordinate );
//                console.log(cities[i].distance(cities[j]));
                  distanceMatrix[i][j] = cities[i].distance(cities[j]);
            }
            else{
                distanceMatrix[i][j] = 0;
            }
        }
    }
    console.log(distanceMatrix);
    loop();
}