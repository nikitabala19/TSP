function city (x, y)
{
    //var xCoordinate;
    //var yCoordinate;
    //var color;
    
    this.xCoordinate = x;
    this.yCoordinate = y;
    
    this.displayCity = function() {
        noStroke();
        fill(255);
        ellipse(this.xCoordinate,this.yCoordinate,10,10);
    }

    this.equals = function(other) {
        if(this.xCoordinate == other.xCoordinate && this.yCoordinate == other.yCoordinate)
            return true;
        else
            return false;
        
    }
    
    this.distance = function(other) {
        tempDistance = floor(dist(this.xCoordinate,this.yCoordinate,other.xCoordinate,other.yCoordinate));
        return tempDistance;
    }
}