var counter=0;
function TSP(startCity, setOfCities, cities ){
    counter++;
    console.log("Calling TSP funciton : " + counter);
    console.log(startCity);
    console.log(setOfCities);
    if(setOfCities.length == 0 ){
        console.log("Returning call for start city");
        console.log(startCity);
        return cities[0].distance(startCity);
    }
    else if(setOfCities.length == 1){
        var temp1 = startCity.distance(setOfCities[0]);
        var newSetOfCities_1 =[]
        var temp2 = TSP(setOfCities[0],newSetOfCities_1,cities);
        return (temp1+temp2);
    }
    else{
        var currentDistances = [];
        for(var i=0; i<setOfCities.length; i++){
            var newStartCity = setOfCities[i];
            var newSetOfCities = [];
            for(var j=0;j<setOfCities.length; j++){
                if(i!=j){
                    append(newSetOfCities,setOfCities[j]);
                }
            }
            var temp2 = TSP(newStartCity,newSetOfCities,cities);
            var temp1 = startCity.distance(newStartCity); 
            append(currentDistances,temp1+temp2);
            console.log(currentDistances);    
        }
        currentDistances = sort(currentDistances);
        console.log(currentDistances);
        return currentDistances[0];
    }
}

/*funtion Minimum(x,y){
    
}*/